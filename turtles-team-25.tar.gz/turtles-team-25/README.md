# turtles-team-25
A Chingu Voyage Build to Learn project to develop a Google Chrome Extension- Design Inspired from New Tab Clock(https://chrome.google.com/webstore/detail/new-tab-clock/ljpapphpgkmigobbbakmnfoohclifanm) and Beautab(https://chrome.google.com/webstore/detail/beautab-productivity-dash/cnpicfljkbmnahnbhfojphebedmmbaij?hl=en) chrome extensions

Team:
@naved
@rahulkumar082
@saeedjassani

Using Github-
1. Clone the repository to local PCs using Github Desktop. Go to the Github website and click on Clone or Download, then select Gihub Desktop and choose appropriate dstination to save and work from.
2. Each member should crete a branch in local PC(Branch->New Branch) and work on that branch, updating the branch every time desktop app is opened(by clicking on Fetch Origin) and pushing the changes to master once done. Once you are done working on the code, click commit to master from your local branch after filling in Summary.
3. Pull the changes you made to your local branch to the master branch. To do this go to Github Website and then the repo->Pull requests-> Create Pull Request -> Merge pull request->Confirm Merge.

Tasks remaining-
1. Decide on Icon for extension.
2. Style the clock, quote and weather. Add active/hiding effects on the temprature toggler.
3. Add settings to customize page-  font changer, Background changer. Need to download fonts and backgrounds. 
4. Add bootstrap to code.
5. Test the extension
6. Publish it on Chrome!
